/*
 * 
 */
package cscie97.asn3.squaredesk.renter;

/**
 * The Class BookingNotFoundException.
 */
public class BookingNotFoundException extends Exception {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 7048341869979294690L;

	public BookingNotFoundException(String string) {
		// TODO Auto-generated constructor stub
	}

}
