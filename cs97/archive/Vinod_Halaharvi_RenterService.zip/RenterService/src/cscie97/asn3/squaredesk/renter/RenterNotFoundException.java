/**
 * 
 */
package cscie97.asn3.squaredesk.renter;

/**
 * The Class RenterNotFoundException.
 */
public class RenterNotFoundException extends Exception {

	/** The Constant serialVersionUID. */

	/**
	 * 
	 */
	private static final long serialVersionUID = 1150723028383550802L;

	/**
	 * 
	 */
	public RenterNotFoundException() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param arg0
	 */
	public RenterNotFoundException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param arg0
	 */
	public RenterNotFoundException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param arg0
	 * @param arg1
	 */
	public RenterNotFoundException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

}
