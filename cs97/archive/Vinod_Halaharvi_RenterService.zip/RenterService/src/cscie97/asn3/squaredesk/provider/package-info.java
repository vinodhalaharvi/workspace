/**
 * 
 */
/**
 * @author s2687
 *
 */
package cscie97.asn3.squaredesk.provider;