/**
 * 
 */
package cscie97.asn4.squaredesk.provider;

/**
 * The Class ImportExecption.
 */
public class ImportExecption extends Exception {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1140072623702558238L;

	/**
	 * Instantiates a new import execption.
	 */
	public ImportExecption() {
	}

	/**
	 * Instantiates a new import execption.
	 *
	 * @param arg0 the arg0
	 */
	public ImportExecption(String arg0) {
		super(arg0);
	}

	/**
	 * Instantiates a new import execption.
	 *
	 * @param arg0 the arg0
	 */
	public ImportExecption(Throwable arg0) {
		super(arg0);
	}

	/**
	 * Instantiates a new import execption.
	 *
	 * @param arg0 the arg0
	 * @param arg1 the arg1
	 */
	public ImportExecption(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

}
