/**
 * 
 */
package cscie97.asn3.squaredesk.renter;

/**
 * The Class RenterAlreadyExistException.
 */
public class RenterAlreadyExistException extends Exception {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 5827507850203009048L;

	/**
	 * 
	 */
	public RenterAlreadyExistException() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param arg0
	 */
	public RenterAlreadyExistException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param arg0
	 */
	public RenterAlreadyExistException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param arg0
	 * @param arg1
	 */
	public RenterAlreadyExistException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param arg0
	 * @param arg1
	 * @param arg2
	 * @param arg3
	 */
	public RenterAlreadyExistException(String arg0, Throwable arg1,
			boolean arg2, boolean arg3) {
		super();
		// TODO Auto-generated constructor stub
	}

}
