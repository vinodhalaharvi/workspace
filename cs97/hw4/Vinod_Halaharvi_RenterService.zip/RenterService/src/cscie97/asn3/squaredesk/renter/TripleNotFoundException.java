/**
 * 
 */
package cscie97.asn3.squaredesk.renter;

/**
 * The Class TripleNotFoundException.
 */
public class TripleNotFoundException extends Exception {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -2446226948529625952L;

	/**
	 * 
	 */

	/**
	 * 
	 */
	public TripleNotFoundException() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param arg0
	 */
	public TripleNotFoundException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param arg0
	 */
	public TripleNotFoundException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param arg0
	 * @param arg1
	 */
	public TripleNotFoundException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param arg0
	 * @param arg1
	 * @param arg2
	 * @param arg3
	 */
	public TripleNotFoundException(String arg0, Throwable arg1, boolean arg2,
			boolean arg3) {
		super();
		// TODO Auto-generated constructor stub
	}

}
