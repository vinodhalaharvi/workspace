﻿Vinod Halaharvi
HUID: 80778287
halavin@iit.edu, vinod.halaharvi@gmail.com,(904) 200 1070

REFERENCE and CREDIT.
#################################
PLEASE NOTE THAT I AM USING SNAKEYAML FOR THIS PROJECT, SO ALL CREDIT DUE TO SNAKEYAML FOR INPUT PARSING!!!
#################################

Please find the design document 'RenterService/Vinod_Halaharvi_DesignDocument_hw3.pdf'
Please also see results.pdf for comments about Design document and Sample run output.
